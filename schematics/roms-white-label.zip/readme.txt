Defender WHITE label romset
^^^^^^^^^^^^^^^^^^^^^^^^^^^
Dumped by Andrew Welburn
on a wet and rainy morning 08/08/08
http://www.andys-arcade.com


In order to help a thread on KLOV forums, i was urged to dump my 
rom board on the insistance of Chris Hardy.

Now, i do actually run the defender pilot/proto page on the net, 
but this pcb did not come from that machine, it came from a 
random bunch of pcbs from an operator in the south of England.

see the photo for the pcb itself.

Make of it what you will....

enjoy!

Andrew Welburn
http://www.andys-arcade.com

